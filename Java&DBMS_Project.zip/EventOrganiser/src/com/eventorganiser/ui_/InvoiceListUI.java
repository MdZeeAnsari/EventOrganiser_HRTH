package com.eventorganiser.ui_;

import com.eventorganiser.dao.InvoiceDAO;
import com.eventorganiser.model.Invoice;
import com.eventorganiser.util.NavigationManager;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.List;

public class InvoiceListUI extends JFrame {

    private JTable invoiceTable;
    private DefaultTableModel tableModel;
    private InvoiceDAO invoiceDAO = new InvoiceDAO();
    private List<Invoice> invoiceList;

    public InvoiceListUI() {
        setTitle("All Invoices");
        setSize(900, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Search Bar
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JTextField txtSearch = new JTextField(20);
        JButton btnSearch = new JButton("Search");
        JButton btnBack = new JButton("← Back");
        searchPanel.add(btnBack);
        searchPanel.add(new JLabel("Search:"));
        searchPanel.add(txtSearch);
        searchPanel.add(btnSearch);
        mainPanel.add(searchPanel, BorderLayout.NORTH);

        // Table
        String[] columns = {"ID", "Invoice No", "Invoice Date", "Event Date", "Client", "Grand Total", "Status"};
        tableModel = new DefaultTableModel(columns, 0) {
            public boolean isCellEditable(int row, int col) { return false; }
        };
        invoiceTable = new JTable(tableModel);
        invoiceTable.setRowHeight(25);
        invoiceTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scrollPane = new JScrollPane(invoiceTable);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        // Buttons
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnRefresh = new JButton("Refresh");
        JButton btnNewInvoice = new JButton("+ New Invoice");
        btnNewInvoice.setBackground(new Color(33, 97, 140));
        btnNewInvoice.setForeground(Color.WHITE);
        JButton btnView = new JButton("View");
        JButton btnEdit = new JButton("Edit");
        JButton btnDelete = new JButton("Delete");
        btnDelete.setBackground(new Color(200, 50, 50));
        btnDelete.setForeground(Color.WHITE);

        btnPanel.add(btnRefresh);
        btnPanel.add(btnView);
        btnPanel.add(btnEdit);
        btnPanel.add(btnNewInvoice);
        btnPanel.add(btnDelete);
        mainPanel.add(btnPanel, BorderLayout.SOUTH);

        // Actions
        btnBack.addActionListener(e -> NavigationManager.goBack(this));

        btnRefresh.addActionListener(e -> loadInvoices());

        btnNewInvoice.addActionListener(e -> NavigationManager.navigate(this, new InvoiceFormUI()));

        btnView.addActionListener(e -> {
            int row = invoiceTable.getSelectedRow();
            if (row < 0) {
                JOptionPane.showMessageDialog(null, "Please select an invoice!");
                return;
            }
            new InvoiceViewUI(invoiceList.get(row).getId()).setVisible(true);
        });

        btnEdit.addActionListener(e -> {
            int row = invoiceTable.getSelectedRow();
            if (row < 0) {
                JOptionPane.showMessageDialog(null, "Please select an invoice!");
                return;
            }
            NavigationManager.navigate(this, new InvoiceEditUI(invoiceList.get(row).getId()));
        });

        btnDelete.addActionListener(e -> {
            int row = invoiceTable.getSelectedRow();
            if (row < 0) {
                JOptionPane.showMessageDialog(null, "Please select an invoice!");
                return;
            }
            int confirm = JOptionPane.showConfirmDialog(null,
                "Are you sure you want to delete this invoice?",
                "Confirm Delete", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                boolean deleted = invoiceDAO.deleteInvoice(invoiceList.get(row).getId());
                if (deleted) {
                    JOptionPane.showMessageDialog(null, "Invoice deleted!");
                    loadInvoices();
                } else {
                    JOptionPane.showMessageDialog(null, "Error deleting invoice!");
                }
            }
        });

        btnSearch.addActionListener(e -> {
            String query = txtSearch.getText().toLowerCase();
            tableModel.setRowCount(0);
            SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
            for (Invoice inv : invoiceList) {
                if (inv.getInvoiceNo().toLowerCase().contains(query) ||
                    inv.getClient().getName().toLowerCase().contains(query) ||
                    inv.getStatus().toLowerCase().contains(query)) {
                    tableModel.addRow(new Object[]{
                        inv.getId(),
                        inv.getInvoiceNo(),
                        inv.getInvoiceDate() != null ? sdf.format(inv.getInvoiceDate()) : "",
                        inv.getEventDate() != null ? sdf.format(inv.getEventDate()) : "",
                        inv.getClient().getName(),
                        String.format("%.2f", inv.getGrandTotal()),
                        inv.getStatus()
                    });
                }
            }
        });

        add(mainPanel);
        loadInvoices();
        setVisible(true);
    }

    private void loadInvoices() {
        tableModel.setRowCount(0);
        invoiceList = invoiceDAO.getAllInvoices();
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        for (Invoice inv : invoiceList) {
            tableModel.addRow(new Object[]{
                inv.getId(),
                inv.getInvoiceNo(),
                inv.getInvoiceDate() != null ? sdf.format(inv.getInvoiceDate()) : "",
                inv.getEventDate() != null ? sdf.format(inv.getEventDate()) : "",
                inv.getClient().getName(),
                String.format("%.2f", inv.getGrandTotal()),
                inv.getStatus()
            });
        }
    }
}