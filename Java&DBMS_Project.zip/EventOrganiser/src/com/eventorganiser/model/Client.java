package com.eventorganiser.model;

public class Client {
    private int id;
    private String name;
    private String address;
    private String gstNo;
    private String contact;
    private String email;

    public Client() {}

    public Client(int id, String name, String address, String gstNo, String contact, String email) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.gstNo = gstNo;
        this.contact = contact;
        this.email = email;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getGstNo() { return gstNo; }
    public void setGstNo(String gstNo) { this.gstNo = gstNo; }

    public String getContact() { return contact; }
    public void setContact(String contact) { this.contact = contact; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
}