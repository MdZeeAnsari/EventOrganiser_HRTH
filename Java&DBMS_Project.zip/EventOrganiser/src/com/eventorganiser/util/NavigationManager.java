package com.eventorganiser.util;

import javax.swing.*;
import java.util.LinkedList;

public class NavigationManager {

    private static LinkedList<JFrame> history = new LinkedList<>();
    private static LinkedList<JFrame> forward = new LinkedList<>();

    public static void navigate(JFrame from, JFrame to) {
        if (from != null) {
            history.push(from);
            from.setVisible(false);
        }
        forward.clear();
        to.setVisible(true);
    }

    public static void goBack(JFrame current) {
        if (!history.isEmpty()) {
            forward.push(current);
            current.setVisible(false);
            JFrame prev = history.pop();
            prev.setVisible(true);
        }
    }

    public static void goForward(JFrame current) {
        if (!forward.isEmpty()) {
            history.push(current);
            current.setVisible(false);
            JFrame next = forward.pop();
            next.setVisible(true);
        }
    }

    public static boolean canGoBack() {
        return !history.isEmpty();
    }

    public static boolean canGoForward() {
        return !forward.isEmpty();
    }
}