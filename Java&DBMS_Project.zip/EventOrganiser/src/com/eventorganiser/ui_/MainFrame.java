package com.eventorganiser.ui_;

import com.eventorganiser.util.NavigationManager;
import com.eventorganiser.util.ThemeManager;

import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {

    public MainFrame() {
        setTitle("HR Tent House & Caterers - Invoice Manager");
        setSize(1000, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Menu Bar
        JMenuBar menuBar = new JMenuBar();

        JMenu invoiceMenu = new JMenu("Invoice");
        JMenuItem newInvoice = new JMenuItem("New Invoice");
        JMenuItem viewInvoices = new JMenuItem("View All Invoices");
        invoiceMenu.add(newInvoice);
        invoiceMenu.add(viewInvoices);
        menuBar.add(invoiceMenu);

        JMenu clientMenu = new JMenu("Clients");
        JMenuItem manageClients = new JMenuItem("Manage Clients");
        clientMenu.add(manageClients);
        menuBar.add(clientMenu);

        JMenu reportsMenu = new JMenu("Reports");
        JMenuItem dashboard = new JMenuItem("Dashboard");
        reportsMenu.add(dashboard);
        menuBar.add(reportsMenu);

        JMenu settingsMenu = new JMenu("Settings");
        JMenuItem toggleTheme = new JMenuItem("Toggle Dark Mode");
        settingsMenu.add(toggleTheme);
        menuBar.add(settingsMenu);

        setJMenuBar(menuBar);

        // Home Panel
        JPanel homePanel = new JPanel(new GridBagLayout());
        homePanel.setBackground(new Color(245, 245, 245));

        JLabel titleLabel = new JLabel("HR Tent House & Caterers");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 26));
        titleLabel.setForeground(new Color(33, 97, 140));

        JLabel subLabel = new JLabel("Invoice Management System");
        subLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        subLabel.setForeground(Color.GRAY);

        JButton btnNewInvoice = new JButton("+ New Invoice");
        btnNewInvoice.setFont(new Font("Arial", Font.BOLD, 14));
        btnNewInvoice.setBackground(new Color(33, 97, 140));
        btnNewInvoice.setForeground(Color.WHITE);
        btnNewInvoice.setPreferredSize(new Dimension(200, 45));

        JButton btnViewInvoices = new JButton("View All Invoices");
        btnViewInvoices.setFont(new Font("Arial", Font.BOLD, 14));
        btnViewInvoices.setPreferredSize(new Dimension(200, 45));

        JButton btnManageClients = new JButton("Manage Clients");
        btnManageClients.setFont(new Font("Arial", Font.BOLD, 14));
        btnManageClients.setPreferredSize(new Dimension(200, 45));

        JButton btnDashboard = new JButton("Dashboard");
        btnDashboard.setFont(new Font("Arial", Font.BOLD, 14));
        btnDashboard.setBackground(new Color(39, 174, 96));
        btnDashboard.setForeground(Color.WHITE);
        btnDashboard.setPreferredSize(new Dimension(200, 45));

        JButton btnDarkMode = new JButton("🌙 Dark Mode");
        btnDarkMode.setFont(new Font("Arial", Font.BOLD, 14));
        btnDarkMode.setPreferredSize(new Dimension(200, 45));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.insets = new Insets(10, 0, 10, 0);

        gbc.gridy = 0;
        homePanel.add(titleLabel, gbc);
        gbc.gridy = 1;
        homePanel.add(subLabel, gbc);
        gbc.gridy = 2;
        homePanel.add(btnDashboard, gbc);
        gbc.gridy = 3;
        homePanel.add(btnNewInvoice, gbc);
        gbc.gridy = 4;
        homePanel.add(btnViewInvoices, gbc);
        gbc.gridy = 5;
        homePanel.add(btnManageClients, gbc);
        gbc.gridy = 6;
        homePanel.add(btnDarkMode, gbc);

        add(homePanel);

        // Actions
        newInvoice.addActionListener(e -> NavigationManager.navigate(this, new InvoiceFormUI()));
        viewInvoices.addActionListener(e -> NavigationManager.navigate(this, new InvoiceListUI()));
        manageClients.addActionListener(e -> NavigationManager.navigate(this, new ClientManagementUI()));
        dashboard.addActionListener(e -> NavigationManager.navigate(this, new DashboardUI()));

        btnNewInvoice.addActionListener(e -> NavigationManager.navigate(this, new InvoiceFormUI()));
        btnViewInvoices.addActionListener(e -> NavigationManager.navigate(this, new InvoiceListUI()));
        btnManageClients.addActionListener(e -> NavigationManager.navigate(this, new ClientManagementUI()));
        btnDashboard.addActionListener(e -> NavigationManager.navigate(this, new DashboardUI()));

        btnDarkMode.addActionListener(e -> {
            ThemeManager.toggleDarkMode(this);
            btnDarkMode.setText(ThemeManager.isDarkMode() ? "☀️ Light Mode" : "🌙 Dark Mode");
        });

        toggleTheme.addActionListener(e -> {
            ThemeManager.toggleDarkMode(this);
            btnDarkMode.setText(ThemeManager.isDarkMode() ? "☀️ Light Mode" : "🌙 Dark Mode");
        });

        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainFrame());
    }
}