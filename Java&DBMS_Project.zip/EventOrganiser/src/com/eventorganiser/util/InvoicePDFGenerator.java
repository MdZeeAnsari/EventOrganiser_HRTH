package com.eventorganiser.util;

import com.eventorganiser.model.Invoice;
import com.eventorganiser.model.InvoiceItem;
import com.lowagie.text.*;
import com.lowagie.text.pdf.*;

import java.awt.Color;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;

public class InvoicePDFGenerator {

    public static String generateInvoice(Invoice inv, String outputPath) {
        try {
            Document document = new Document(PageSize.A4);
            PdfWriter.getInstance(document, new FileOutputStream(outputPath));
            document.open();

            SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");

            // Fonts
            Font titleFont = new Font(Font.HELVETICA, 16, Font.BOLD);
            Font boldFont = new Font(Font.HELVETICA, 10, Font.BOLD);
            Font normalFont = new Font(Font.HELVETICA, 9, Font.NORMAL);
            Font smallFont = new Font(Font.HELVETICA, 8, Font.NORMAL);

            // Company Header
            PdfPTable headerTable = new PdfPTable(1);
            headerTable.setWidthPercentage(100);

            PdfPCell companyCell = new PdfPCell();
            companyCell.setBorder(Rectangle.BOX);
            companyCell.setPadding(8);

            Paragraph companyName = new Paragraph("HR TENT HOUSE & CATERERS", titleFont);
            companyName.setAlignment(Element.ALIGN_CENTER);
            companyCell.addElement(companyName);

            Paragraph companyAddress = new Paragraph(
                "No 1, 14th cross, Bhuvaneshwari Nagar, R T Nagar Post, Bangalore - 560032\n" +
                "Email: hrtenhouse2021@gmail.com | Contact: 9902020244 / 9164111158\n" +
                "GST No: 29AIIPA6377N1ZN | HSN Code: 9963", smallFont);
            companyAddress.setAlignment(Element.ALIGN_CENTER);
            companyCell.addElement(companyAddress);

            headerTable.addCell(companyCell);
            document.add(headerTable);

            // Invoice Title
            PdfPTable titleTable = new PdfPTable(1);
            titleTable.setWidthPercentage(100);
            PdfPCell titleCell = new PdfPCell(new Phrase("I N V O I C E", boldFont));
            titleCell.setHorizontalAlignment(Element.ALIGN_CENTER);
            titleCell.setBackgroundColor(new Color(220, 220, 220));
            titleCell.setPadding(5);
            titleTable.addCell(titleCell);
            document.add(titleTable);

            // Bill To and Invoice Details
            PdfPTable billTable = new PdfPTable(2);
            billTable.setWidthPercentage(100);
            billTable.setWidths(new float[]{50, 50});

            // Left - Bill To
            PdfPCell billToCell = new PdfPCell();
            billToCell.setBorder(Rectangle.BOX);
            billToCell.setPadding(5);
            billToCell.addElement(new Paragraph("Bill To:", boldFont));
            billToCell.addElement(new Paragraph(inv.getClient().getName(), boldFont));
            if (inv.getClient().getAddress() != null)
                billToCell.addElement(new Paragraph(inv.getClient().getAddress(), normalFont));
            if (inv.getClient().getGstNo() != null)
                billToCell.addElement(new Paragraph("GST No: " + inv.getClient().getGstNo(), normalFont));
            billTable.addCell(billToCell);

            // Right - Invoice Details
            PdfPCell invoiceDetailCell = new PdfPCell();
            invoiceDetailCell.setBorder(Rectangle.BOX);
            invoiceDetailCell.setPadding(5);
            invoiceDetailCell.addElement(new Paragraph("Invoice No: " + inv.getInvoiceNo(), normalFont));
            invoiceDetailCell.addElement(new Paragraph("Invoice Date: " + (inv.getInvoiceDate() != null ? sdf.format(inv.getInvoiceDate()) : ""), normalFont));
            invoiceDetailCell.addElement(new Paragraph("Event Date: " + (inv.getEventDate() != null ? sdf.format(inv.getEventDate()) : ""), normalFont));
            if (inv.getOrderNo() != null)
                invoiceDetailCell.addElement(new Paragraph("Order No: " + inv.getOrderNo(), normalFont));
            if (inv.getTransporter() != null)
                invoiceDetailCell.addElement(new Paragraph("Transporter: " + inv.getTransporter(), normalFont));
            if (inv.getRrLrNo() != null)
                invoiceDetailCell.addElement(new Paragraph("RR/LR No: " + inv.getRrLrNo(), normalFont));
            billTable.addCell(invoiceDetailCell);

            document.add(billTable);

            // Items Table
            PdfPTable itemsTable = new PdfPTable(7);
            itemsTable.setWidthPercentage(100);
            itemsTable.setWidths(new float[]{5, 30, 12, 8, 8, 12, 15});
            itemsTable.setSpacingBefore(5);

            // Table Header
            String[] headers = {"SL.NO", "DESCRIPTION", "HSN CODE", "DAYS", "QTY", "RATE", "AMOUNT"};
            for (String h : headers) {
                PdfPCell cell = new PdfPCell(new Phrase(h, boldFont));
                cell.setBackgroundColor(new Color(200, 200, 200));
                cell.setHorizontalAlignment(Element.ALIGN_CENTER);
                cell.setPadding(5);
                itemsTable.addCell(cell);
            }

            // Table Rows
            for (InvoiceItem item : inv.getItems()) {
                itemsTable.addCell(new PdfPCell(new Phrase(String.valueOf(item.getSlNo()), normalFont)));
                itemsTable.addCell(new PdfPCell(new Phrase(item.getDescription() != null ? item.getDescription() : "", normalFont)));
                itemsTable.addCell(new PdfPCell(new Phrase(item.getHsnCode() != null ? item.getHsnCode() : "", normalFont)));

                PdfPCell daysCell = new PdfPCell(new Phrase(item.isLumpsum() ? "LS" : String.valueOf(item.getDays()), normalFont));
                daysCell.setHorizontalAlignment(Element.ALIGN_CENTER);
                itemsTable.addCell(daysCell);

                PdfPCell qtyCell = new PdfPCell(new Phrase(item.isLumpsum() ? "-" : String.format("%.2f", item.getQty()), normalFont));
                qtyCell.setHorizontalAlignment(Element.ALIGN_CENTER);
                itemsTable.addCell(qtyCell);

                PdfPCell rateCell = new PdfPCell(new Phrase(item.isLumpsum() ? "-" : String.format("%.2f", item.getRate()), normalFont));
                rateCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
                itemsTable.addCell(rateCell);

                PdfPCell amountCell = new PdfPCell(new Phrase(String.format("%.2f", item.getAmount()), normalFont));
                amountCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
                itemsTable.addCell(amountCell);
            }

            document.add(itemsTable);

            // Totals Table
            PdfPTable totalsTable = new PdfPTable(2);
            totalsTable.setWidthPercentage(40);
            totalsTable.setHorizontalAlignment(Element.ALIGN_RIGHT);
            totalsTable.setSpacingBefore(5);

            addTotalRow(totalsTable, "Sub Total:", String.format("%.2f", inv.getSubTotal()), normalFont, boldFont, false);
            addTotalRow(totalsTable, "CGST @ " + inv.getCgstPercent() + "%:", String.format("%.2f", inv.getCgstAmount()), normalFont, boldFont, false);
            addTotalRow(totalsTable, "SGST @ " + inv.getSgstPercent() + "%:", String.format("%.2f", inv.getSgstAmount()), normalFont, boldFont, false);
            addTotalRow(totalsTable, "Round Off:", String.format("%.2f", inv.getRoundOff()), normalFont, boldFont, false);
            addTotalRow(totalsTable, "GRAND TOTAL:", String.format("%.2f", inv.getGrandTotal()), normalFont, boldFont, true);

            document.add(totalsTable);

            // Amount in Words
            if (inv.getAmountInWords() != null && !inv.getAmountInWords().isEmpty()) {
                Paragraph amountWords = new Paragraph("Amount in Words: " + inv.getAmountInWords(), boldFont);
                amountWords.setSpacingBefore(5);
                document.add(amountWords);
            }

            // Terms and Conditions
            Paragraph terms = new Paragraph(
                "\nTERMS & CONDITIONS:\n" +
                "* Order once booked will not be taken back\n" +
                "* Subject to Bangalore Jurisdiction\n" +
                "* Goods are sent at buyer's risk.", smallFont);
            document.add(terms);

            // Bank Details and Signature
            PdfPTable footerTable = new PdfPTable(2);
            footerTable.setWidthPercentage(100);
            footerTable.setSpacingBefore(10);

            PdfPCell bankCell = new PdfPCell();
            bankCell.setBorder(Rectangle.BOX);
            bankCell.setPadding(5);
            bankCell.addElement(new Paragraph("Bank Details:", boldFont));
            bankCell.addElement(new Paragraph("Bank: BANK OF BARODA", normalFont));
            bankCell.addElement(new Paragraph("A/c: 92030200001441", normalFont));
            bankCell.addElement(new Paragraph("IFSC: BARB0DBCHOL", normalFont));
            footerTable.addCell(bankCell);

            PdfPCell signCell = new PdfPCell();
            signCell.setBorder(Rectangle.BOX);
            signCell.setPadding(5);
            signCell.addElement(new Paragraph("For HR TENT HOUSE & CATERERS", boldFont));
            signCell.addElement(new Paragraph("\n\n\nAuthorised Signatory", normalFont));
            footerTable.addCell(signCell);

            document.add(footerTable);

            document.close();
            return outputPath;

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private static void addTotalRow(PdfPTable table, String label, String value, Font normalFont, Font boldFont, boolean isGrand) {
        Font f = isGrand ? boldFont : normalFont;
        PdfPCell labelCell = new PdfPCell(new Phrase(label, f));
        labelCell.setPadding(4);
        table.addCell(labelCell);

        PdfPCell valueCell = new PdfPCell(new Phrase(value, f));
        valueCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        valueCell.setPadding(4);
        table.addCell(valueCell);
    }
}