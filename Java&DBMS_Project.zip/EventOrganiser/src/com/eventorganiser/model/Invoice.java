package com.eventorganiser.model;

import java.util.Date;
import java.util.List;

public class Invoice {

    private int id;
    private String invoiceNo;
    private Date invoiceDate;
    private Date eventDate;
    private String orderNo;
    private Date orderDate;
    private Client client;
    private String transporter;
    private String rrLrNo;
    private double subTotal;
    private double cgstPercent;
    private double cgstAmount;
    private double sgstPercent;
    private double sgstAmount;
    private double igstPercent;
    private double igstAmount;
    private double roundOff;
    private double grandTotal;
    private String amountInWords;
    private String status;
    private List<InvoiceItem> items;

    public Invoice() {}

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getInvoiceNo() { return invoiceNo; }
    public void setInvoiceNo(String invoiceNo) { this.invoiceNo = invoiceNo; }

    public Date getInvoiceDate() { return invoiceDate; }
    public void setInvoiceDate(Date invoiceDate) { this.invoiceDate = invoiceDate; }

    public Date getEventDate() { return eventDate; }
    public void setEventDate(Date eventDate) { this.eventDate = eventDate; }

    public String getOrderNo() { return orderNo; }
    public void setOrderNo(String orderNo) { this.orderNo = orderNo; }

    public Date getOrderDate() { return orderDate; }
    public void setOrderDate(Date orderDate) { this.orderDate = orderDate; }

    public Client getClient() { return client; }
    public void setClient(Client client) { this.client = client; }

    public String getTransporter() { return transporter; }
    public void setTransporter(String transporter) { this.transporter = transporter; }

    public String getRrLrNo() { return rrLrNo; }
    public void setRrLrNo(String rrLrNo) { this.rrLrNo = rrLrNo; }

    public double getSubTotal() { return subTotal; }
    public void setSubTotal(double subTotal) { this.subTotal = subTotal; }

    public double getCgstPercent() { return cgstPercent; }
    public void setCgstPercent(double cgstPercent) { this.cgstPercent = cgstPercent; }

    public double getCgstAmount() { return cgstAmount; }
    public void setCgstAmount(double cgstAmount) { this.cgstAmount = cgstAmount; }

    public double getSgstPercent() { return sgstPercent; }
    public void setSgstPercent(double sgstPercent) { this.sgstPercent = sgstPercent; }

    public double getSgstAmount() { return sgstAmount; }
    public void setSgstAmount(double sgstAmount) { this.sgstAmount = sgstAmount; }

    public double getIgstPercent() { return igstPercent; }
    public void setIgstPercent(double igstPercent) { this.igstPercent = igstPercent; }

    public double getIgstAmount() { return igstAmount; }
    public void setIgstAmount(double igstAmount) { this.igstAmount = igstAmount; }

    public double getRoundOff() { return roundOff; }
    public void setRoundOff(double roundOff) { this.roundOff = roundOff; }

    public double getGrandTotal() { return grandTotal; }
    public void setGrandTotal(double grandTotal) { this.grandTotal = grandTotal; }

    public String getAmountInWords() { return amountInWords; }
    public void setAmountInWords(String amountInWords) { this.amountInWords = amountInWords; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public List<InvoiceItem> getItems() { return items; }
    public void setItems(List<InvoiceItem> items) { this.items = items; }
}