package com.eventorganiser.ui_;

import com.eventorganiser.dao.ClientDAO;
import com.eventorganiser.dao.InvoiceDAO;
import com.eventorganiser.model.Client;
import com.eventorganiser.model.Invoice;
import com.eventorganiser.model.InvoiceItem;
import com.eventorganiser.util.NumberToWords;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class InvoiceEditUI extends JFrame {

    private JTextField txtInvoiceNo, txtInvoiceDate, txtEventDate, txtOrderNo, txtOrderDate;
    private JTextField txtTransporter, txtRrLrNo;
    private JComboBox<String> cbClient;
    private List<Client> clientList;

    private JTable itemTable;
    private DefaultTableModel tableModel;

    private JLabel lblSubTotal, lblCGST, lblSGST, lblRoundOff, lblGrandTotal;
    private JTextField txtCgstPercent, txtSgstPercent;

    private ClientDAO clientDAO = new ClientDAO();
    private InvoiceDAO invoiceDAO = new InvoiceDAO();
    private Invoice existingInvoice;

    public InvoiceEditUI(int invoiceId) {
        setTitle("Edit Invoice");
        setSize(1100, 750);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        existingInvoice = invoiceDAO.getInvoiceById(invoiceId);
        if (existingInvoice == null) {
            JOptionPane.showMessageDialog(null, "Invoice not found!");
            dispose();
            return;
        }

        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");

        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Header Panel
        JPanel headerPanel = new JPanel(new GridLayout(3, 4, 10, 10));
        headerPanel.setBorder(BorderFactory.createTitledBorder("Invoice Details"));

        txtInvoiceNo = new JTextField(existingInvoice.getInvoiceNo());
        txtInvoiceDate = new JTextField(existingInvoice.getInvoiceDate() != null ? sdf.format(existingInvoice.getInvoiceDate()) : "");
        txtEventDate = new JTextField(existingInvoice.getEventDate() != null ? sdf.format(existingInvoice.getEventDate()) : "");
        txtOrderNo = new JTextField(existingInvoice.getOrderNo() != null ? existingInvoice.getOrderNo() : "");
        txtOrderDate = new JTextField(existingInvoice.getOrderDate() != null ? sdf.format(existingInvoice.getOrderDate()) : "");
        txtTransporter = new JTextField(existingInvoice.getTransporter() != null ? existingInvoice.getTransporter() : "");
        txtRrLrNo = new JTextField(existingInvoice.getRrLrNo() != null ? existingInvoice.getRrLrNo() : "");

        cbClient = new JComboBox<>();
        loadClients();

        // Select existing client
        for (int i = 0; i < clientList.size(); i++) {
            if (clientList.get(i).getId() == existingInvoice.getClient().getId()) {
                cbClient.setSelectedIndex(i);
                break;
            }
        }

        headerPanel.add(new JLabel("Invoice No:"));
        headerPanel.add(txtInvoiceNo);
        headerPanel.add(new JLabel("Invoice Date:"));
        headerPanel.add(txtInvoiceDate);

        headerPanel.add(new JLabel("Event Date:"));
        headerPanel.add(txtEventDate);
        headerPanel.add(new JLabel("Order No:"));
        headerPanel.add(txtOrderNo);

        headerPanel.add(new JLabel("Client:"));
        headerPanel.add(cbClient);
        headerPanel.add(new JLabel("Transporter:"));
        headerPanel.add(txtTransporter);

        // Items Table
        String[] columns = {"SL", "Description", "HSN Code", "Days", "Qty", "Rate", "Amount", "Lumpsum"};
        tableModel = new DefaultTableModel(columns, 0) {
            public Class getColumnClass(int col) {
                if (col == 7) return Boolean.class;
                return String.class;
            }
        };
        itemTable = new JTable(tableModel);
        itemTable.setRowHeight(25);

        // Load existing items
        int slNo = 1;
        for (InvoiceItem item : existingInvoice.getItems()) {
            tableModel.addRow(new Object[]{
                String.valueOf(slNo++),
                item.getDescription(),
                item.getHsnCode(),
                String.valueOf(item.getDays()),
                String.valueOf(item.getQty()),
                String.valueOf(item.getRate()),
                String.valueOf(item.getAmount()),
                item.isLumpsum()
            });
        }

        JScrollPane tableScroll = new JScrollPane(itemTable);
        tableScroll.setBorder(BorderFactory.createTitledBorder("Invoice Items"));
        tableScroll.setPreferredSize(new Dimension(1000, 300));

        JPanel tableButtonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton btnAddRow = new JButton("+ Add Row");
        JButton btnDeleteRow = new JButton("- Delete Row");
        tableButtonPanel.add(btnAddRow);
        tableButtonPanel.add(btnDeleteRow);

        btnAddRow.addActionListener(e -> tableModel.addRow(new Object[]{"", "", "", "1", "", "", "", false}));
        btnDeleteRow.addActionListener(e -> {
            int row = itemTable.getSelectedRow();
            if (row >= 0) tableModel.removeRow(row);
            calculateTotals();
        });

        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.add(tableButtonPanel, BorderLayout.NORTH);
        centerPanel.add(tableScroll, BorderLayout.CENTER);

        // Totals Panel
        JPanel totalPanel = new JPanel(new GridLayout(6, 2, 5, 5));
        totalPanel.setBorder(BorderFactory.createTitledBorder("Totals"));

        lblSubTotal = new JLabel(String.format("%.2f", existingInvoice.getSubTotal()));
        txtCgstPercent = new JTextField(String.valueOf(existingInvoice.getCgstPercent()));
        lblCGST = new JLabel(String.format("%.2f", existingInvoice.getCgstAmount()));
        txtSgstPercent = new JTextField(String.valueOf(existingInvoice.getSgstPercent()));
        lblSGST = new JLabel(String.format("%.2f", existingInvoice.getSgstAmount()));
        lblRoundOff = new JLabel(String.format("%.2f", existingInvoice.getRoundOff()));
        lblGrandTotal = new JLabel(String.format("%.2f", existingInvoice.getGrandTotal()));
        lblGrandTotal.setFont(new Font("Arial", Font.BOLD, 14));

        totalPanel.add(new JLabel("Sub Total:"));
        totalPanel.add(lblSubTotal);
        totalPanel.add(new JLabel("CGST %:"));
        totalPanel.add(txtCgstPercent);
        totalPanel.add(new JLabel("CGST Amount:"));
        totalPanel.add(lblCGST);
        totalPanel.add(new JLabel("SGST %:"));
        totalPanel.add(txtSgstPercent);
        totalPanel.add(new JLabel("SGST Amount:"));
        totalPanel.add(lblSGST);
        totalPanel.add(new JLabel("Grand Total:"));
        totalPanel.add(lblGrandTotal);

        // Action Buttons
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnCalculate = new JButton("Calculate");
        JButton btnUpdate = new JButton("Update Invoice");
        btnUpdate.setBackground(new Color(33, 97, 140));
        btnUpdate.setForeground(Color.WHITE);
        btnUpdate.setFont(new Font("Arial", Font.BOLD, 13));

        btnCalculate.addActionListener(e -> {
            // Stop any active editing
            if (itemTable.isEditing()) {
                itemTable.getCellEditor().stopCellEditing();
            }

            for (int i = 0; i < tableModel.getRowCount(); i++) {
                try {
                    Object lumpsumVal = tableModel.getValueAt(i, 7);
                    boolean isLumpsum = lumpsumVal != null && (Boolean) lumpsumVal;

                    if (!isLumpsum) {
                        Object daysObj = tableModel.getValueAt(i, 3);
                        Object qtyObj = tableModel.getValueAt(i, 4);
                        Object rateObj = tableModel.getValueAt(i, 5);

                        double days = (daysObj == null || daysObj.toString().isEmpty()) ? 1 : Double.parseDouble(daysObj.toString());
                        double qty = (qtyObj == null || qtyObj.toString().isEmpty()) ? 0 : Double.parseDouble(qtyObj.toString());
                        double rate = (rateObj == null || rateObj.toString().isEmpty()) ? 0 : Double.parseDouble(rateObj.toString());

                        double amount = days * qty * rate;
                        tableModel.setValueAt(String.format("%.2f", amount), i, 6);
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Error in row " + (i+1) + ": " + ex.getMessage());
                }
            }
            calculateTotals();
        });
        btnUpdate.addActionListener(e -> updateInvoice());

        actionPanel.add(btnCalculate);
        actionPanel.add(btnUpdate);

        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(centerPanel, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.add(totalPanel, BorderLayout.CENTER);
        bottomPanel.add(actionPanel, BorderLayout.SOUTH);
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        add(mainPanel);
        setVisible(true);
    }

    private void loadClients() {
        cbClient.removeAllItems();
        clientList = clientDAO.getAllClients();
        for (Client c : clientList) {
            cbClient.addItem(c.getName());
        }
    }

    private void calculateTotals() {
        double subTotal = 0;
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            try {
                String amountStr = (String) tableModel.getValueAt(i, 6);
                if (amountStr != null && !amountStr.isEmpty()) {
                    subTotal += Double.parseDouble(amountStr);
                }
            } catch (Exception e) {}
        }

        double cgstPct = Double.parseDouble(txtCgstPercent.getText().isEmpty() ? "0" : txtCgstPercent.getText());
        double sgstPct = Double.parseDouble(txtSgstPercent.getText().isEmpty() ? "0" : txtSgstPercent.getText());

        double cgst = subTotal * cgstPct / 100;
        double sgst = subTotal * sgstPct / 100;
        double grand = subTotal + cgst + sgst;
        double roundOff = Math.round(grand) - grand;

        lblSubTotal.setText(String.format("%.2f", subTotal));
        lblCGST.setText(String.format("%.2f", cgst));
        lblSGST.setText(String.format("%.2f", sgst));
        lblRoundOff.setText(String.format("%.2f", roundOff));
        lblGrandTotal.setText(String.format("%.2f", grand + roundOff));
    }

    private void updateInvoice() {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");

            existingInvoice.setInvoiceNo(txtInvoiceNo.getText());
            existingInvoice.setInvoiceDate(sdf.parse(txtInvoiceDate.getText()));
            if (!txtEventDate.getText().isEmpty())
                existingInvoice.setEventDate(sdf.parse(txtEventDate.getText()));
            existingInvoice.setOrderNo(txtOrderNo.getText());
            existingInvoice.setTransporter(txtTransporter.getText());

            int selectedIndex = cbClient.getSelectedIndex();
            if (selectedIndex < 0) {
                JOptionPane.showMessageDialog(null, "Please select a client!");
                return;
            }
            existingInvoice.setClient(clientList.get(selectedIndex));

            double subTotal = Double.parseDouble(lblSubTotal.getText());
            double cgstPct = Double.parseDouble(txtCgstPercent.getText());
            double sgstPct = Double.parseDouble(txtSgstPercent.getText());
            double cgst = Double.parseDouble(lblCGST.getText());
            double sgst = Double.parseDouble(lblSGST.getText());
            double grand = Double.parseDouble(lblGrandTotal.getText());

            existingInvoice.setSubTotal(subTotal);
            existingInvoice.setCgstPercent(cgstPct);
            existingInvoice.setCgstAmount(cgst);
            existingInvoice.setSgstPercent(sgstPct);
            existingInvoice.setSgstAmount(sgst);
            existingInvoice.setGrandTotal(grand);
            existingInvoice.setAmountInWords(NumberToWords.convert(grand));
            existingInvoice.setStatus("FINAL");

            List<InvoiceItem> items = new ArrayList<>();
            for (int i = 0; i < tableModel.getRowCount(); i++) {
                InvoiceItem item = new InvoiceItem();
                item.setSlNo(i + 1);
                item.setDescription((String) tableModel.getValueAt(i, 1));
                item.setHsnCode((String) tableModel.getValueAt(i, 2));
                item.setDays(Integer.parseInt(tableModel.getValueAt(i, 3).toString().isEmpty() ? "1" : tableModel.getValueAt(i, 3).toString()));
                item.setQty(tableModel.getValueAt(i, 4).toString().isEmpty() ? 0 : Double.parseDouble(tableModel.getValueAt(i, 4).toString()));
                item.setRate(tableModel.getValueAt(i, 5).toString().isEmpty() ? 0 : Double.parseDouble(tableModel.getValueAt(i, 5).toString()));
                item.setAmount(tableModel.getValueAt(i, 6).toString().isEmpty() ? 0 : Double.parseDouble(tableModel.getValueAt(i, 6).toString()));
                item.setLumpsum((Boolean) tableModel.getValueAt(i, 7));
                items.add(item);
            }
            existingInvoice.setItems(items);

            boolean updated = invoiceDAO.updateInvoice(existingInvoice);
            if (updated) {
                JOptionPane.showMessageDialog(null, "Invoice updated successfully!");
                dispose();
            } else {
                JOptionPane.showMessageDialog(null, "Error updating invoice!");
            }

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }
}