package com.eventorganiser.util;

public class NumberToWords {

    private static final String[] ones = {
        "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine",
        "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen",
        "Seventeen", "Eighteen", "Nineteen"
    };

    private static final String[] tens = {
        "", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"
    };

    public static String convert(double amount) {
        long rupees = (long) amount;
        long paise = Math.round((amount - rupees) * 100);

        String result = "Rupees " + convertToWords(rupees);
        if (paise > 0) {
            result += " and " + convertToWords(paise) + " Paise";
        }
        result += " Only";
        return result;
    }

    private static String convertToWords(long number) {
        if (number == 0) return "Zero";

        if (number < 0) return "Minus " + convertToWords(-number);

        String words = "";

        if (number / 10000000 > 0) {
            words += convertToWords(number / 10000000) + " Crore ";
            number %= 10000000;
        }

        if (number / 100000 > 0) {
            words += convertToWords(number / 100000) + " Lakh ";
            number %= 100000;
        }

        if (number / 1000 > 0) {
            words += convertToWords(number / 1000) + " Thousand ";
            number %= 1000;
        }

        if (number / 100 > 0) {
            words += convertToWords(number / 100) + " Hundred ";
            number %= 100;
        }

        if (number > 0) {
            if (number < 20) {
                words += ones[(int) number];
            } else {
                words += tens[(int) (number / 10)];
                if (number % 10 > 0) {
                    words += " " + ones[(int) (number % 10)];
                }
            }
        }

        return words.trim();
    }
}