package com.eventorganiser.ui_;

import com.eventorganiser.db.DBConnection;
import com.eventorganiser.util.NavigationManager;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class DashboardUI extends JFrame {

    public DashboardUI() {
        setTitle("Dashboard");
        setSize(1000, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        mainPanel.setBackground(new Color(245, 245, 245));

        // Top - Back + Title
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(new Color(245, 245, 245));

        JButton btnBack = new JButton("← Back");
        btnBack.addActionListener(e -> NavigationManager.goBack(this));
        topPanel.add(btnBack, BorderLayout.WEST);

        JLabel titleLabel = new JLabel("Dashboard - Business Overview");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(new Color(33, 97, 140));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        topPanel.add(titleLabel, BorderLayout.CENTER);

        mainPanel.add(topPanel, BorderLayout.NORTH);

        // Stats Panel
        JPanel statsPanel = new JPanel(new GridLayout(2, 3, 15, 15));
        statsPanel.setBackground(new Color(245, 245, 245));
        statsPanel.setBorder(BorderFactory.createEmptyBorder(30, 0, 20, 0));

        int totalInvoices = 0;
        double totalRevenue = 0;
        double totalGST = 0;
        int totalClients = 0;
        int paidInvoices = 0;
        int draftInvoices = 0;

        try (Connection con = DBConnection.getConnection()) {
            ResultSet rs1 = con.createStatement().executeQuery("SELECT COUNT(*) FROM invoices");
            if (rs1.next()) totalInvoices = rs1.getInt(1);

            ResultSet rs2 = con.createStatement().executeQuery("SELECT SUM(grand_total) FROM invoices");
            if (rs2.next()) totalRevenue = rs2.getDouble(1);

            ResultSet rs3 = con.createStatement().executeQuery("SELECT SUM(cgst_amount + sgst_amount) FROM invoices");
            if (rs3.next()) totalGST = rs3.getDouble(1);

            ResultSet rs4 = con.createStatement().executeQuery("SELECT COUNT(*) FROM clients");
            if (rs4.next()) totalClients = rs4.getInt(1);

            ResultSet rs5 = con.createStatement().executeQuery("SELECT COUNT(*) FROM invoices WHERE status='PAID'");
            if (rs5.next()) paidInvoices = rs5.getInt(1);

            ResultSet rs6 = con.createStatement().executeQuery("SELECT COUNT(*) FROM invoices WHERE status='DRAFT'");
            if (rs6.next()) draftInvoices = rs6.getInt(1);

        } catch (SQLException e) {
            e.printStackTrace();
        }

        statsPanel.add(createCard("Total Invoices", String.valueOf(totalInvoices), new Color(52, 152, 219)));
        statsPanel.add(createCard("Total Revenue", String.format("₹ %.2f", totalRevenue), new Color(39, 174, 96)));
        statsPanel.add(createCard("Total GST Collected", String.format("₹ %.2f", totalGST), new Color(230, 126, 34)));
        statsPanel.add(createCard("Total Clients", String.valueOf(totalClients), new Color(155, 89, 182)));
        statsPanel.add(createCard("Paid Invoices", String.valueOf(paidInvoices), new Color(26, 188, 156)));
        statsPanel.add(createCard("Draft Invoices", String.valueOf(draftInvoices), new Color(231, 76, 60)));

        mainPanel.add(statsPanel, BorderLayout.CENTER);

        // Recent Invoices
        JPanel recentPanel = new JPanel(new BorderLayout());
        recentPanel.setBorder(BorderFactory.createTitledBorder("Recent Invoices"));
        recentPanel.setPreferredSize(new Dimension(750, 150));

        String[] columns = {"Invoice No", "Client", "Grand Total", "Status"};
        Object[][] data = getRecentInvoices();
        JTable recentTable = new JTable(data, columns) {
            public boolean isCellEditable(int row, int col) { return false; }
        };
        recentTable.setRowHeight(25);
        recentPanel.add(new JScrollPane(recentTable), BorderLayout.CENTER);

        mainPanel.add(recentPanel, BorderLayout.SOUTH);

        add(mainPanel);
        setVisible(true);
    }

    private JPanel createCard(String title, String value, Color color) {
        JPanel card = new JPanel(new GridBagLayout());
        card.setBackground(color);
        card.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Arial", Font.PLAIN, 13));
        titleLabel.setForeground(Color.WHITE);
        gbc.gridy = 0;
        card.add(titleLabel, gbc);

        JLabel valueLabel = new JLabel(value);
        valueLabel.setFont(new Font("Arial", Font.BOLD, 20));
        valueLabel.setForeground(Color.WHITE);
        gbc.gridy = 1;
        card.add(valueLabel, gbc);

        return card;
    }

    private Object[][] getRecentInvoices() {
        try (Connection con = DBConnection.getConnection()) {
            ResultSet rs = con.createStatement().executeQuery(
                "SELECT i.invoice_no, c.name, i.grand_total, i.status " +
                "FROM invoices i JOIN clients c ON i.client_id = c.id " +
                "ORDER BY i.created_at DESC LIMIT 5"
            );
            java.util.List<Object[]> rows = new java.util.ArrayList<>();
            while (rs.next()) {
                rows.add(new Object[]{
                    rs.getString("invoice_no"),
                    rs.getString("name"),
                    String.format("₹ %.2f", rs.getDouble("grand_total")),
                    rs.getString("status")
                });
            }
            return rows.toArray(new Object[0][]);
        } catch (SQLException e) {
            e.printStackTrace();
            return new Object[0][0];
        }
    }
}