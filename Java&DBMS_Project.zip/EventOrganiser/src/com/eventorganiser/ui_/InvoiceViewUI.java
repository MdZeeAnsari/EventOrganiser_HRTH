package com.eventorganiser.ui_;

import com.eventorganiser.dao.InvoiceDAO;
import com.eventorganiser.model.Invoice;
import com.eventorganiser.model.InvoiceItem;
import com.eventorganiser.util.InvoicePDFGenerator;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.File;
import java.text.SimpleDateFormat;

public class InvoiceViewUI extends JFrame {

    private InvoiceDAO invoiceDAO = new InvoiceDAO();

    public InvoiceViewUI(int invoiceId) {
        setTitle("View Invoice");
        setSize(900, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        Invoice inv = invoiceDAO.getInvoiceById(invoiceId);
        if (inv == null) {
            JOptionPane.showMessageDialog(null, "Invoice not found!");
            dispose();
            return;
        }

        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");

        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Header
        JPanel headerPanel = new JPanel(new GridLayout(0, 2, 5, 5));
        headerPanel.setBorder(BorderFactory.createTitledBorder("Invoice Details"));

        headerPanel.add(new JLabel("Invoice No:"));
        headerPanel.add(new JLabel(inv.getInvoiceNo()));

        headerPanel.add(new JLabel("Invoice Date:"));
        headerPanel.add(new JLabel(inv.getInvoiceDate() != null ? sdf.format(inv.getInvoiceDate()) : ""));

        headerPanel.add(new JLabel("Event Date:"));
        headerPanel.add(new JLabel(inv.getEventDate() != null ? sdf.format(inv.getEventDate()) : ""));

        headerPanel.add(new JLabel("Client:"));
        headerPanel.add(new JLabel(inv.getClient().getName()));

        headerPanel.add(new JLabel("Client GST:"));
        headerPanel.add(new JLabel(inv.getClient().getGstNo() != null ? inv.getClient().getGstNo() : ""));

        headerPanel.add(new JLabel("Order No:"));
        headerPanel.add(new JLabel(inv.getOrderNo() != null ? inv.getOrderNo() : ""));

        headerPanel.add(new JLabel("Transporter:"));
        headerPanel.add(new JLabel(inv.getTransporter() != null ? inv.getTransporter() : ""));

        headerPanel.add(new JLabel("Status:"));
        headerPanel.add(new JLabel(inv.getStatus()));

        // Items Table
        String[] columns = {"SL", "Description", "HSN Code", "Days", "Qty", "Rate", "Amount"};
        DefaultTableModel tableModel = new DefaultTableModel(columns, 0) {
            public boolean isCellEditable(int row, int col) { return false; }
        };

        int slNo = 1;
        for (InvoiceItem item : inv.getItems()) {
            tableModel.addRow(new Object[]{
                slNo++,
                item.getDescription(),
                item.getHsnCode(),
                item.isLumpsum() ? "LS" : String.valueOf(item.getDays()),
                item.isLumpsum() ? "-" : String.format("%.2f", item.getQty()),
                item.isLumpsum() ? "-" : String.format("%.2f", item.getRate()),
                String.format("%.2f", item.getAmount())
            });
        }

        JTable itemTable = new JTable(tableModel);
        itemTable.setRowHeight(25);
        JScrollPane scrollPane = new JScrollPane(itemTable);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Items"));

        // Totals
        JPanel totalPanel = new JPanel(new GridLayout(0, 2, 5, 5));
        totalPanel.setBorder(BorderFactory.createTitledBorder("Totals"));

        totalPanel.add(new JLabel("Sub Total:"));
        totalPanel.add(new JLabel(String.format("%.2f", inv.getSubTotal())));

        totalPanel.add(new JLabel("CGST @ " + inv.getCgstPercent() + "%:"));
        totalPanel.add(new JLabel(String.format("%.2f", inv.getCgstAmount())));

        totalPanel.add(new JLabel("SGST @ " + inv.getSgstPercent() + "%:"));
        totalPanel.add(new JLabel(String.format("%.2f", inv.getSgstAmount())));

        totalPanel.add(new JLabel("Round Off:"));
        totalPanel.add(new JLabel(String.format("%.2f", inv.getRoundOff())));

        JLabel grandTotalLabel = new JLabel("GRAND TOTAL:");
        grandTotalLabel.setFont(new Font("Arial", Font.BOLD, 14));
        JLabel grandTotalValue = new JLabel(String.format("%.2f", inv.getGrandTotal()));
        grandTotalValue.setFont(new Font("Arial", Font.BOLD, 14));

        totalPanel.add(grandTotalLabel);
        totalPanel.add(grandTotalValue);

        totalPanel.add(new JLabel("Amount in Words:"));
        totalPanel.add(new JLabel(inv.getAmountInWords() != null ? inv.getAmountInWords() : ""));

        // Buttons
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnExportPDF = new JButton("Export PDF");
        btnExportPDF.setBackground(new Color(33, 97, 140));
        btnExportPDF.setForeground(Color.WHITE);
        btnExportPDF.setFont(new Font("Arial", Font.BOLD, 13));
        JButton btnClose = new JButton("Close");

        btnClose.addActionListener(e -> dispose());

        btnExportPDF.addActionListener(e -> {
            // Show print preview first
            int preview = JOptionPane.showConfirmDialog(null,
                "Invoice No: " + inv.getInvoiceNo() + "\n" +
                "Client: " + inv.getClient().getName() + "\n" +
                "Grand Total: ₹ " + String.format("%.2f", inv.getGrandTotal()) + "\n" +
                "Amount in Words: " + inv.getAmountInWords() + "\n\n" +
                "Do you want to export this invoice as PDF?",
                "Print Preview",
                JOptionPane.YES_NO_OPTION);

            if (preview == JOptionPane.YES_OPTION) {
                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setSelectedFile(new File("Invoice_" + inv.getInvoiceNo() + ".pdf"));
                int result = fileChooser.showSaveDialog(null);
                if (result == JFileChooser.APPROVE_OPTION) {
                    String path = fileChooser.getSelectedFile().getAbsolutePath();
                    if (!path.endsWith(".pdf")) path += ".pdf";
                    String generated = InvoicePDFGenerator.generateInvoice(inv, path);
                    if (generated != null) {
                        JOptionPane.showMessageDialog(null, "PDF saved to: " + path);
                        try {
                            Desktop.getDesktop().open(new File(path));
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Error generating PDF!");
                    }
                }
            }
        });

        btnPanel.add(btnExportPDF);
        btnPanel.add(btnClose);

        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.add(totalPanel, BorderLayout.CENTER);
        bottomPanel.add(btnPanel, BorderLayout.SOUTH);
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        add(mainPanel);
    }
}