package com.eventorganiser.ui_;

import com.eventorganiser.dao.ClientDAO;
import com.eventorganiser.model.Client;
import com.eventorganiser.util.NavigationManager;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class ClientManagementUI extends JFrame {

    private JTable clientTable;
    private DefaultTableModel tableModel;
    private ClientDAO clientDAO = new ClientDAO();
    private List<Client> clientList;

    public ClientManagementUI() {
        setTitle("Client Management");
        setSize(800, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Search
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton btnBack = new JButton("← Back");
        JTextField txtSearch = new JTextField(20);
        JButton btnSearch = new JButton("Search");
        searchPanel.add(btnBack);
        searchPanel.add(new JLabel("Search:"));
        searchPanel.add(txtSearch);
        searchPanel.add(btnSearch);
        mainPanel.add(searchPanel, BorderLayout.NORTH);

        // Table
        String[] columns = {"ID", "Name", "Address", "GST No", "Contact", "Email"};
        tableModel = new DefaultTableModel(columns, 0) {
            public boolean isCellEditable(int row, int col) { return false; }
        };
        clientTable = new JTable(tableModel);
        clientTable.setRowHeight(25);
        clientTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scrollPane = new JScrollPane(clientTable);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        // Buttons
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnAdd = new JButton("+ Add Client");
        btnAdd.setBackground(new Color(33, 97, 140));
        btnAdd.setForeground(Color.WHITE);
        JButton btnEdit = new JButton("Edit");
        JButton btnDelete = new JButton("Delete");
        btnDelete.setBackground(new Color(200, 50, 50));
        btnDelete.setForeground(Color.WHITE);
        JButton btnRefresh = new JButton("Refresh");

        btnPanel.add(btnRefresh);
        btnPanel.add(btnEdit);
        btnPanel.add(btnAdd);
        btnPanel.add(btnDelete);
        mainPanel.add(btnPanel, BorderLayout.SOUTH);

        // Actions
        btnBack.addActionListener(e -> NavigationManager.goBack(this));

        btnRefresh.addActionListener(e -> loadClients());

        btnAdd.addActionListener(e -> {
            showClientDialog(null);
            loadClients();
        });

        btnEdit.addActionListener(e -> {
            int row = clientTable.getSelectedRow();
            if (row < 0) {
                JOptionPane.showMessageDialog(null, "Please select a client!");
                return;
            }
            showClientDialog(clientList.get(row));
            loadClients();
        });

        btnDelete.addActionListener(e -> {
            int row = clientTable.getSelectedRow();
            if (row < 0) {
                JOptionPane.showMessageDialog(null, "Please select a client!");
                return;
            }
            int confirm = JOptionPane.showConfirmDialog(null,
                "Are you sure you want to delete this client?",
                "Confirm Delete", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                boolean deleted = clientDAO.deleteClient(clientList.get(row).getId());
                if (deleted) {
                    JOptionPane.showMessageDialog(null, "Client deleted!");
                    loadClients();
                } else {
                    JOptionPane.showMessageDialog(null, "Error deleting client!");
                }
            }
        });

        btnSearch.addActionListener(e -> {
            String query = txtSearch.getText().toLowerCase();
            tableModel.setRowCount(0);
            for (Client c : clientList) {
                if (c.getName().toLowerCase().contains(query) ||
                    (c.getGstNo() != null && c.getGstNo().toLowerCase().contains(query)) ||
                    (c.getContact() != null && c.getContact().toLowerCase().contains(query))) {
                    tableModel.addRow(new Object[]{
                        c.getId(), c.getName(), c.getAddress(),
                        c.getGstNo(), c.getContact(), c.getEmail()
                    });
                }
            }
        });

        add(mainPanel);
        loadClients();
        setVisible(true);
    }

    private void showClientDialog(Client existing) {
        JTextField txtName = new JTextField(existing != null ? existing.getName() : "");
        JTextField txtAddress = new JTextField(existing != null ? existing.getAddress() : "");
        JTextField txtGst = new JTextField(existing != null ? existing.getGstNo() : "");
        JTextField txtContact = new JTextField(existing != null ? existing.getContact() : "");
        JTextField txtEmail = new JTextField(existing != null ? existing.getEmail() : "");

        Object[] fields = {
            "Name:", txtName,
            "Address:", txtAddress,
            "GST No:", txtGst,
            "Contact:", txtContact,
            "Email:", txtEmail
        };

        String title = existing != null ? "Edit Client" : "Add New Client";
        int result = JOptionPane.showConfirmDialog(null, fields, title, JOptionPane.OK_CANCEL_OPTION);

        if (result == JOptionPane.OK_OPTION) {
            Client c = existing != null ? existing : new Client();
            c.setName(txtName.getText());
            c.setAddress(txtAddress.getText());
            c.setGstNo(txtGst.getText());
            c.setContact(txtContact.getText());
            c.setEmail(txtEmail.getText());

            if (existing != null) {
                clientDAO.updateClient(c);
            } else {
                clientDAO.addClient(c);
            }
        }
    }

    private void loadClients() {
        tableModel.setRowCount(0);
        clientList = clientDAO.getAllClients();
        for (Client c : clientList) {
            tableModel.addRow(new Object[]{
                c.getId(), c.getName(), c.getAddress(),
                c.getGstNo(), c.getContact(), c.getEmail()
            });
        }
    }
}