package com.eventorganiser.dao;

import com.eventorganiser.db.DBConnection;
import com.eventorganiser.model.Client;
import com.eventorganiser.model.Invoice;
import com.eventorganiser.model.InvoiceItem;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class InvoiceDAO {

    // Save full invoice with items
    public boolean saveInvoice(Invoice invoice) {
        Connection con = null;
        try {
            con = DBConnection.getConnection();
            con.setAutoCommit(false);

            // Insert invoice
            String sql = "INSERT INTO invoices (invoice_no, invoice_date, event_date, order_no, order_date, "
                    + "client_id, transporter, rr_lr_no, sub_total, cgst_percent, cgst_amount, "
                    + "sgst_percent, sgst_amount, igst_percent, igst_amount, round_off, "
                    + "grand_total, amount_in_words, status) "
                    + "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

            PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, invoice.getInvoiceNo());
            ps.setDate(2, new java.sql.Date(invoice.getInvoiceDate().getTime()));
            ps.setDate(3, invoice.getEventDate() != null ? new java.sql.Date(invoice.getEventDate().getTime()) : null);
            ps.setString(4, invoice.getOrderNo());
            ps.setDate(5, invoice.getOrderDate() != null ? new java.sql.Date(invoice.getOrderDate().getTime()) : null);
            ps.setInt(6, invoice.getClient().getId());
            ps.setString(7, invoice.getTransporter());
            ps.setString(8, invoice.getRrLrNo());
            ps.setDouble(9, invoice.getSubTotal());
            ps.setDouble(10, invoice.getCgstPercent());
            ps.setDouble(11, invoice.getCgstAmount());
            ps.setDouble(12, invoice.getSgstPercent());
            ps.setDouble(13, invoice.getSgstAmount());
            ps.setDouble(14, invoice.getIgstPercent());
            ps.setDouble(15, invoice.getIgstAmount());
            ps.setDouble(16, invoice.getRoundOff());
            ps.setDouble(17, invoice.getGrandTotal());
            ps.setString(18, invoice.getAmountInWords());
            ps.setString(19, invoice.getStatus());
            ps.executeUpdate();

            // Get generated invoice ID
            ResultSet rs = ps.getGeneratedKeys();
            int invoiceId = 0;
            if (rs.next()) {
                invoiceId = rs.getInt(1);
            }

            // Insert invoice items
            String itemSql = "INSERT INTO invoice_items (invoice_id, sl_no, description, hsn_code, days, qty, rate, amount, is_lumpsum) "
                    + "VALUES (?,?,?,?,?,?,?,?,?)";
            PreparedStatement itemPs = con.prepareStatement(itemSql);
            for (InvoiceItem item : invoice.getItems()) {
                itemPs.setInt(1, invoiceId);
                itemPs.setInt(2, item.getSlNo());
                itemPs.setString(3, item.getDescription());
                itemPs.setString(4, item.getHsnCode());
                itemPs.setInt(5, item.getDays());
                itemPs.setDouble(6, item.getQty());
                itemPs.setDouble(7, item.getRate());
                itemPs.setDouble(8, item.getAmount());
                itemPs.setBoolean(9, item.isLumpsum());
                itemPs.addBatch();
            }
            itemPs.executeBatch();

            con.commit();
            return true;

        } catch (SQLException e) {
            try { if (con != null) con.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
            e.printStackTrace();
            return false;
        } finally {
            try { if (con != null) con.close(); } catch (SQLException e) { e.printStackTrace(); }
        }
    }

    // Get all invoices (list view)
    public List<Invoice> getAllInvoices() {
        List<Invoice> list = new ArrayList<>();
        String sql = "SELECT i.id, i.invoice_no, i.invoice_date, i.event_date, i.grand_total, i.status, "
                + "c.name as client_name FROM invoices i "
                + "JOIN clients c ON i.client_id = c.id ORDER BY i.created_at DESC";
        try (Connection con = DBConnection.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                Invoice inv = new Invoice();
                inv.setId(rs.getInt("id"));
                inv.setInvoiceNo(rs.getString("invoice_no"));
                inv.setInvoiceDate(rs.getDate("invoice_date"));
                inv.setEventDate(rs.getDate("event_date"));
                inv.setGrandTotal(rs.getDouble("grand_total"));
                inv.setStatus(rs.getString("status"));
                Client c = new Client();
                c.setName(rs.getString("client_name"));
                inv.setClient(c);
                list.add(inv);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    // Get single invoice with all items
    public Invoice getInvoiceById(int id) {
        String sql = "SELECT i.*, c.name as client_name, c.address as client_address, "
                + "c.gst_no as client_gst, c.contact as client_contact "
                + "FROM invoices i JOIN clients c ON i.client_id = c.id WHERE i.id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Invoice inv = new Invoice();
                inv.setId(rs.getInt("id"));
                inv.setInvoiceNo(rs.getString("invoice_no"));
                inv.setInvoiceDate(rs.getDate("invoice_date"));
                inv.setEventDate(rs.getDate("event_date"));
                inv.setOrderNo(rs.getString("order_no"));
                inv.setOrderDate(rs.getDate("order_date"));
                inv.setTransporter(rs.getString("transporter"));
                inv.setRrLrNo(rs.getString("rr_lr_no"));
                inv.setSubTotal(rs.getDouble("sub_total"));
                inv.setCgstPercent(rs.getDouble("cgst_percent"));
                inv.setCgstAmount(rs.getDouble("cgst_amount"));
                inv.setSgstPercent(rs.getDouble("sgst_percent"));
                inv.setSgstAmount(rs.getDouble("sgst_amount"));
                inv.setIgstPercent(rs.getDouble("igst_percent"));
                inv.setIgstAmount(rs.getDouble("igst_amount"));
                inv.setRoundOff(rs.getDouble("round_off"));
                inv.setGrandTotal(rs.getDouble("grand_total"));
                inv.setAmountInWords(rs.getString("amount_in_words"));
                inv.setStatus(rs.getString("status"));

                Client c = new Client();
                c.setName(rs.getString("client_name"));
                c.setAddress(rs.getString("client_address"));
                c.setGstNo(rs.getString("client_gst"));
                c.setContact(rs.getString("client_contact"));
                inv.setClient(c);

                // Load items
                inv.setItems(getItemsByInvoiceId(con, id));
                return inv;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Get items for an invoice
    private List<InvoiceItem> getItemsByInvoiceId(Connection con, int invoiceId) throws SQLException {
        List<InvoiceItem> items = new ArrayList<>();
        String sql = "SELECT * FROM invoice_items WHERE invoice_id = ? ORDER BY sl_no";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setInt(1, invoiceId);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            InvoiceItem item = new InvoiceItem();
            item.setId(rs.getInt("id"));
            item.setSlNo(rs.getInt("sl_no"));
            item.setDescription(rs.getString("description"));
            item.setHsnCode(rs.getString("hsn_code"));
            item.setDays(rs.getInt("days"));
            item.setQty(rs.getDouble("qty"));
            item.setRate(rs.getDouble("rate"));
            item.setAmount(rs.getDouble("amount"));
            item.setLumpsum(rs.getBoolean("is_lumpsum"));
            items.add(item);
        }
        return items;
    }
    public boolean deleteInvoice(int id) {
        String sql = "DELETE FROM invoices WHERE id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    public boolean updateInvoice(Invoice invoice) {
        Connection con = null;
        try {
            con = DBConnection.getConnection();
            con.setAutoCommit(false);

            String sql = "UPDATE invoices SET invoice_no=?, invoice_date=?, event_date=?, order_no=?, order_date=?, "
                    + "client_id=?, transporter=?, rr_lr_no=?, sub_total=?, cgst_percent=?, cgst_amount=?, "
                    + "sgst_percent=?, sgst_amount=?, igst_percent=?, igst_amount=?, round_off=?, "
                    + "grand_total=?, amount_in_words=?, status=? WHERE id=?";

            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, invoice.getInvoiceNo());
            ps.setDate(2, new java.sql.Date(invoice.getInvoiceDate().getTime()));
            ps.setDate(3, invoice.getEventDate() != null ? new java.sql.Date(invoice.getEventDate().getTime()) : null);
            ps.setString(4, invoice.getOrderNo());
            ps.setDate(5, invoice.getOrderDate() != null ? new java.sql.Date(invoice.getOrderDate().getTime()) : null);
            ps.setInt(6, invoice.getClient().getId());
            ps.setString(7, invoice.getTransporter());
            ps.setString(8, invoice.getRrLrNo());
            ps.setDouble(9, invoice.getSubTotal());
            ps.setDouble(10, invoice.getCgstPercent());
            ps.setDouble(11, invoice.getCgstAmount());
            ps.setDouble(12, invoice.getSgstPercent());
            ps.setDouble(13, invoice.getSgstAmount());
            ps.setDouble(14, invoice.getIgstPercent());
            ps.setDouble(15, invoice.getIgstAmount());
            ps.setDouble(16, invoice.getRoundOff());
            ps.setDouble(17, invoice.getGrandTotal());
            ps.setString(18, invoice.getAmountInWords());
            ps.setString(19, invoice.getStatus());
            ps.setInt(20, invoice.getId());
            ps.executeUpdate();

            // Delete old items and reinsert
            PreparedStatement delPs = con.prepareStatement("DELETE FROM invoice_items WHERE invoice_id=?");
            delPs.setInt(1, invoice.getId());
            delPs.executeUpdate();

            String itemSql = "INSERT INTO invoice_items (invoice_id, sl_no, description, hsn_code, days, qty, rate, amount, is_lumpsum) "
                    + "VALUES (?,?,?,?,?,?,?,?,?)";
            PreparedStatement itemPs = con.prepareStatement(itemSql);
            for (InvoiceItem item : invoice.getItems()) {
                itemPs.setInt(1, invoice.getId());
                itemPs.setInt(2, item.getSlNo());
                itemPs.setString(3, item.getDescription());
                itemPs.setString(4, item.getHsnCode());
                itemPs.setInt(5, item.getDays());
                itemPs.setDouble(6, item.getQty());
                itemPs.setDouble(7, item.getRate());
                itemPs.setDouble(8, item.getAmount());
                itemPs.setBoolean(9, item.isLumpsum());
                itemPs.addBatch();
            }
            itemPs.executeBatch();

            con.commit();
            return true;

        } catch (SQLException e) {
            try { if (con != null) con.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
            e.printStackTrace();
            return false;
        } finally {
            try { if (con != null) con.close(); } catch (SQLException e) { e.printStackTrace(); }
        }
    }
}