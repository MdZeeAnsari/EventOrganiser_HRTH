package com.eventorganiser.util;

import javax.swing.*;
import java.awt.*;

public class ThemeManager {

    private static boolean isDarkMode = false;

    // Dark mode colors
    public static final Color DARK_BG = new Color(33, 33, 33);
    public static final Color DARK_PANEL = new Color(45, 45, 45);
    public static final Color DARK_TEXT = new Color(220, 220, 220);
    public static final Color DARK_BORDER = new Color(70, 70, 70);
    public static final Color DARK_TABLE_BG = new Color(55, 55, 55);
    public static final Color DARK_TABLE_FG = new Color(220, 220, 220);
    public static final Color DARK_SELECTION = new Color(33, 97, 140);
    public static final Color ACCENT = new Color(33, 97, 140);

    // Light mode colors
    public static final Color LIGHT_BG = new Color(245, 245, 245);
    public static final Color LIGHT_PANEL = Color.WHITE;
    public static final Color LIGHT_TEXT = Color.BLACK;

    public static boolean isDarkMode() { return isDarkMode; }

    public static void toggleDarkMode(JFrame frame) {
        isDarkMode = !isDarkMode;
        applyTheme(frame);
    }

    public static void applyTheme(JFrame frame) {
        applyToComponent(frame.getContentPane());
        SwingUtilities.updateComponentTreeUI(frame);
        frame.repaint();
    }

    public static void applyToComponent(Component comp) {
        if (isDarkMode) {
            comp.setBackground(DARK_BG);
            comp.setForeground(DARK_TEXT);
        } else {
            comp.setBackground(LIGHT_BG);
            comp.setForeground(LIGHT_TEXT);
        }

        if (comp instanceof JPanel) {
            comp.setBackground(isDarkMode ? DARK_PANEL : LIGHT_BG);
        }

        if (comp instanceof JTable) {
            JTable table = (JTable) comp;
            table.setBackground(isDarkMode ? DARK_TABLE_BG : Color.WHITE);
            table.setForeground(isDarkMode ? DARK_TABLE_FG : Color.BLACK);
            table.setGridColor(isDarkMode ? DARK_BORDER : Color.LIGHT_GRAY);
            table.getTableHeader().setBackground(isDarkMode ? DARK_BORDER : new Color(200, 200, 200));
            table.getTableHeader().setForeground(isDarkMode ? DARK_TEXT : Color.BLACK);
            table.setSelectionBackground(DARK_SELECTION);
        }

        if (comp instanceof JTextField) {
            comp.setBackground(isDarkMode ? DARK_TABLE_BG : Color.WHITE);
            comp.setForeground(isDarkMode ? DARK_TEXT : Color.BLACK);
            ((JTextField) comp).setCaretColor(isDarkMode ? DARK_TEXT : Color.BLACK);
        }

        if (comp instanceof JLabel) {
            comp.setForeground(isDarkMode ? DARK_TEXT : Color.BLACK);
        }

        if (comp instanceof JButton) {
            JButton btn = (JButton) comp;
            if (btn.getBackground().equals(new Color(33, 97, 140)) ||
                btn.getBackground().equals(new Color(200, 50, 50)) ||
                btn.getBackground().equals(new Color(39, 174, 96))) {
                // Keep colored buttons as is
            } else {
                btn.setBackground(isDarkMode ? DARK_BORDER : null);
                btn.setForeground(isDarkMode ? DARK_TEXT : Color.BLACK);
            }
        }

        if (comp instanceof Container) {
            for (Component child : ((Container) comp).getComponents()) {
                applyToComponent(child);
            }
        }
    }
}