package com.eventorganiser.model;

public class InvoiceItem {
    private int id;
    private int invoiceId;
    private int slNo;
    private String description;
    private String hsnCode;
    private int days;
    private double qty;
    private double rate;
    private double amount;
    private boolean isLumpsum;

    public InvoiceItem() {}

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getInvoiceId() { return invoiceId; }
    public void setInvoiceId(int invoiceId) { this.invoiceId = invoiceId; }

    public int getSlNo() { return slNo; }
    public void setSlNo(int slNo) { this.slNo = slNo; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getHsnCode() { return hsnCode; }
    public void setHsnCode(String hsnCode) { this.hsnCode = hsnCode; }

    public int getDays() { return days; }
    public void setDays(int days) { this.days = days; }

    public double getQty() { return qty; }
    public void setQty(double qty) { this.qty = qty; }

    public double getRate() { return rate; }
    public void setRate(double rate) { this.rate = rate; }

    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }

    public boolean isLumpsum() { return isLumpsum; }
    public void setLumpsum(boolean isLumpsum) { this.isLumpsum = isLumpsum; }
}