package com.eventorganiser.ui_;

import com.eventorganiser.dao.ClientDAO;
import com.eventorganiser.dao.InvoiceDAO;
import com.eventorganiser.model.Client;
import com.eventorganiser.model.Invoice;
import com.eventorganiser.model.InvoiceItem;
import com.eventorganiser.util.NavigationManager;
import com.eventorganiser.util.NumberToWords;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class InvoiceFormUI extends JFrame {

    private JTextField txtInvoiceNo, txtInvoiceDate, txtEventDate, txtOrderNo;
    private JTextField txtTransporter, txtRrLrNo;
    private JComboBox<String> cbClient;
    private List<Client> clientList;

    private JTable itemTable;
    private DefaultTableModel tableModel;

    private JLabel lblSubTotal, lblCGST, lblSGST, lblRoundOff, lblGrandTotal;
    private JTextField txtCgstPercent, txtSgstPercent;

    private ClientDAO clientDAO = new ClientDAO();
    private InvoiceDAO invoiceDAO = new InvoiceDAO();

    private static final String[] HSN_CODES = {
        "9405", "9403", "9973", "5608", "7610",
        "6306", "9401", "9404", "9963", "9954",
        "9985", "9996", "9983", "996334", "998596"
    };

    public InvoiceFormUI() {
        setTitle("New Invoice");
        setSize(1100, 750);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Header Panel
        JPanel headerPanel = new JPanel(new GridLayout(3, 4, 10, 10));
        headerPanel.setBorder(BorderFactory.createTitledBorder("Invoice Details"));

        txtInvoiceNo = new JTextField(generateInvoiceNo());
        txtInvoiceDate = new JTextField(new SimpleDateFormat("dd-MM-yyyy").format(new Date()));
        txtEventDate = new JTextField();
        txtOrderNo = new JTextField();
        txtTransporter = new JTextField();
        txtRrLrNo = new JTextField();

        // Date picker buttons
        JButton btnInvoiceDate = new JButton("📅");
        btnInvoiceDate.setPreferredSize(new Dimension(40, 25));
        JButton btnEventDate = new JButton("📅");
        btnEventDate.setPreferredSize(new Dimension(40, 25));

        btnInvoiceDate.addActionListener(e -> {
            String date = showDatePicker();
            if (date != null) txtInvoiceDate.setText(date);
        });

        btnEventDate.addActionListener(e -> {
            String date = showDatePicker();
            if (date != null) txtEventDate.setText(date);
        });

        JPanel invoiceDatePanel = new JPanel(new BorderLayout(2, 0));
        invoiceDatePanel.add(txtInvoiceDate, BorderLayout.CENTER);
        invoiceDatePanel.add(btnInvoiceDate, BorderLayout.EAST);

        JPanel eventDatePanel = new JPanel(new BorderLayout(2, 0));
        eventDatePanel.add(txtEventDate, BorderLayout.CENTER);
        eventDatePanel.add(btnEventDate, BorderLayout.EAST);

        cbClient = new JComboBox<>();
        loadClients();

        headerPanel.add(new JLabel("Invoice No:"));
        headerPanel.add(txtInvoiceNo);
        headerPanel.add(new JLabel("Invoice Date:"));
        headerPanel.add(invoiceDatePanel);

        headerPanel.add(new JLabel("Event Date:"));
        headerPanel.add(eventDatePanel);
        headerPanel.add(new JLabel("Order No:"));
        headerPanel.add(txtOrderNo);

        headerPanel.add(new JLabel("Client:"));
        headerPanel.add(cbClient);
        headerPanel.add(new JLabel("Transporter:"));
        headerPanel.add(txtTransporter);

        // Items Table
        String[] columns = {"SL", "Description", "HSN Code", "Days", "Qty", "Rate", "Amount", "Lumpsum"};
        tableModel = new DefaultTableModel(columns, 0) {
            public Class getColumnClass(int col) {
                if (col == 7) return Boolean.class;
                return String.class;
            }
        };

        itemTable = new JTable(tableModel);
        itemTable.setRowHeight(25);

        // HSN dropdown
        JComboBox<String> hsnCombo = new JComboBox<>(HSN_CODES);
        hsnCombo.setEditable(true);
        TableColumn hsnColumn = itemTable.getColumnModel().getColumn(2);
        hsnColumn.setCellEditor(new DefaultCellEditor(hsnCombo));

        // Column widths
        itemTable.getColumnModel().getColumn(0).setPreferredWidth(30);
        itemTable.getColumnModel().getColumn(1).setPreferredWidth(250);
        itemTable.getColumnModel().getColumn(2).setPreferredWidth(80);
        itemTable.getColumnModel().getColumn(3).setPreferredWidth(50);
        itemTable.getColumnModel().getColumn(4).setPreferredWidth(50);
        itemTable.getColumnModel().getColumn(5).setPreferredWidth(80);
        itemTable.getColumnModel().getColumn(6).setPreferredWidth(80);
        itemTable.getColumnModel().getColumn(7).setPreferredWidth(60);

        JScrollPane tableScroll = new JScrollPane(itemTable);
        tableScroll.setBorder(BorderFactory.createTitledBorder("Invoice Items"));
        tableScroll.setPreferredSize(new Dimension(1000, 300));

        JPanel tableButtonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton btnAddRow = new JButton("+ Add Row");
        JButton btnDeleteRow = new JButton("- Delete Row");
        tableButtonPanel.add(btnAddRow);
        tableButtonPanel.add(btnDeleteRow);

        btnAddRow.addActionListener(e -> {
            int rowCount = tableModel.getRowCount() + 1;
            tableModel.addRow(new Object[]{String.valueOf(rowCount), "", HSN_CODES[0], "1", "0", "0", "0.00", false});
        });

        btnDeleteRow.addActionListener(e -> {
            int row = itemTable.getSelectedRow();
            if (row >= 0) {
                tableModel.removeRow(row);
                for (int i = 0; i < tableModel.getRowCount(); i++) {
                    tableModel.setValueAt(String.valueOf(i + 1), i, 0);
                }
            }
        });

        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.add(tableButtonPanel, BorderLayout.NORTH);
        centerPanel.add(tableScroll, BorderLayout.CENTER);

        // Totals Panel
        JPanel totalPanel = new JPanel(new GridLayout(6, 2, 5, 5));
        totalPanel.setBorder(BorderFactory.createTitledBorder("Totals"));

        lblSubTotal = new JLabel("0.00");
        txtCgstPercent = new JTextField("9");
        lblCGST = new JLabel("0.00");
        txtSgstPercent = new JTextField("9");
        lblSGST = new JLabel("0.00");
        lblRoundOff = new JLabel("0.00");
        lblGrandTotal = new JLabel("0.00");
        lblGrandTotal.setFont(new Font("Arial", Font.BOLD, 14));

        totalPanel.add(new JLabel("Sub Total:"));
        totalPanel.add(lblSubTotal);
        totalPanel.add(new JLabel("CGST %:"));
        totalPanel.add(txtCgstPercent);
        totalPanel.add(new JLabel("CGST Amount:"));
        totalPanel.add(lblCGST);
        totalPanel.add(new JLabel("SGST %:"));
        totalPanel.add(txtSgstPercent);
        totalPanel.add(new JLabel("SGST Amount:"));
        totalPanel.add(lblSGST);
        totalPanel.add(new JLabel("Grand Total:"));
        totalPanel.add(lblGrandTotal);

        // Action Buttons
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnBack = new JButton("← Back");
        JButton btnCalculate = new JButton("Calculate");
        JButton btnSave = new JButton("Save Invoice");
        btnSave.setBackground(new Color(33, 97, 140));
        btnSave.setForeground(Color.WHITE);
        btnSave.setFont(new Font("Arial", Font.BOLD, 13));
        JButton btnAddClient = new JButton("+ Add Client");

        btnBack.addActionListener(e -> NavigationManager.goBack(this));

        btnCalculate.addActionListener(e -> {
            if (itemTable.isEditing()) {
                itemTable.getCellEditor().stopCellEditing();
            }
            for (int i = 0; i < tableModel.getRowCount(); i++) {
                try {
                    Object lumpsumVal = tableModel.getValueAt(i, 7);
                    boolean isLumpsum = lumpsumVal != null && (Boolean) lumpsumVal;
                    if (!isLumpsum) {
                        double days = parseDouble(tableModel.getValueAt(i, 3), 1);
                        double qty = parseDouble(tableModel.getValueAt(i, 4), 0);
                        double rate = parseDouble(tableModel.getValueAt(i, 5), 0);
                        double amount = days * qty * rate;
                        tableModel.setValueAt(String.format("%.2f", amount), i, 6);
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
            calculateTotals();
        });

        btnSave.addActionListener(e -> saveInvoice());
        btnAddClient.addActionListener(e -> {
            addNewClient();
            loadClients();
        });

        actionPanel.add(btnBack);
        actionPanel.add(btnAddClient);
        actionPanel.add(btnCalculate);
        actionPanel.add(btnSave);

        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(centerPanel, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.add(totalPanel, BorderLayout.CENTER);
        bottomPanel.add(actionPanel, BorderLayout.SOUTH);
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        add(mainPanel);
        setVisible(true);
    }

    private String generateInvoiceNo() {
        try {
            java.sql.Connection con = com.eventorganiser.db.DBConnection.getConnection();
            java.sql.ResultSet rs = con.createStatement().executeQuery(
                "SELECT COUNT(*) FROM invoices"
            );
            if (rs.next()) {
                int count = rs.getInt(1) + 1;
                if (count < 100) return String.format("%03d", count);
                else return String.valueOf(count);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "001";
    }

    private String showDatePicker() {
        JSpinner dateSpinner = new JSpinner(new SpinnerDateModel());
        JSpinner.DateEditor dateEditor = new JSpinner.DateEditor(dateSpinner, "dd-MM-yyyy");
        dateSpinner.setEditor(dateEditor);
        dateSpinner.setValue(new Date());

        int result = JOptionPane.showConfirmDialog(null, dateSpinner, "Select Date", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            return new SimpleDateFormat("dd-MM-yyyy").format(dateSpinner.getValue());
        }
        return null;
    }

    private double parseDouble(Object val, double defaultVal) {
        if (val == null || val.toString().isEmpty()) return defaultVal;
        try { return Double.parseDouble(val.toString()); }
        catch (Exception e) { return defaultVal; }
    }

    private void loadClients() {
        cbClient.removeAllItems();
        clientList = clientDAO.getAllClients();
        for (Client c : clientList) {
            cbClient.addItem(c.getName());
        }
    }

    private void addNewClient() {
        JTextField name = new JTextField();
        JTextField address = new JTextField();
        JTextField gst = new JTextField();
        JTextField contact = new JTextField();

        Object[] fields = {
            "Name:", name,
            "Address:", address,
            "GST No:", gst,
            "Contact:", contact
        };

        int result = JOptionPane.showConfirmDialog(null, fields, "Add New Client", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            Client c = new Client();
            c.setName(name.getText());
            c.setAddress(address.getText());
            c.setGstNo(gst.getText());
            c.setContact(contact.getText());
            clientDAO.addClient(c);
        }
    }

    private void calculateTotals() {
        double subTotal = 0;
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            subTotal += parseDouble(tableModel.getValueAt(i, 6), 0);
        }

        double cgstPct = parseDouble(txtCgstPercent.getText(), 0);
        double sgstPct = parseDouble(txtSgstPercent.getText(), 0);

        double cgst = subTotal * cgstPct / 100;
        double sgst = subTotal * sgstPct / 100;
        double grand = subTotal + cgst + sgst;
        double roundOff = Math.round(grand) - grand;
        double grandRounded = grand + roundOff;

        lblSubTotal.setText(String.format("%.2f", subTotal));
        lblCGST.setText(String.format("%.2f", cgst));
        lblSGST.setText(String.format("%.2f", sgst));
        lblRoundOff.setText(String.format("%.2f", roundOff));
        lblGrandTotal.setText(String.format("%.2f", grandRounded));
    }

    private void saveInvoice() {
        try {
            if (txtInvoiceNo.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter Invoice No!");
                return;
            }

            if (itemTable.isEditing()) {
                itemTable.getCellEditor().stopCellEditing();
            }

            Invoice invoice = new Invoice();
            invoice.setInvoiceNo(txtInvoiceNo.getText());
            invoice.setInvoiceDate(new SimpleDateFormat("dd-MM-yyyy").parse(txtInvoiceDate.getText()));
            if (!txtEventDate.getText().isEmpty())
                invoice.setEventDate(new SimpleDateFormat("dd-MM-yyyy").parse(txtEventDate.getText()));

            invoice.setOrderNo(txtOrderNo.getText().isEmpty() ? "-" : txtOrderNo.getText());
            invoice.setTransporter(txtTransporter.getText().isEmpty() ? "-" : txtTransporter.getText());
            invoice.setRrLrNo(txtRrLrNo.getText().isEmpty() ? "-" : txtRrLrNo.getText());

            int selectedIndex = cbClient.getSelectedIndex();
            if (selectedIndex < 0) {
                JOptionPane.showMessageDialog(null, "Please select a client!");
                return;
            }
            invoice.setClient(clientList.get(selectedIndex));

            double subTotal = parseDouble(lblSubTotal.getText(), 0);
            double cgstPct = parseDouble(txtCgstPercent.getText(), 0);
            double sgstPct = parseDouble(txtSgstPercent.getText(), 0);
            double cgst = parseDouble(lblCGST.getText(), 0);
            double sgst = parseDouble(lblSGST.getText(), 0);
            double grand = parseDouble(lblGrandTotal.getText(), 0);

            invoice.setSubTotal(subTotal);
            invoice.setCgstPercent(cgstPct);
            invoice.setCgstAmount(cgst);
            invoice.setSgstPercent(sgstPct);
            invoice.setSgstAmount(sgst);
            invoice.setGrandTotal(grand);
            invoice.setStatus("FINAL");
            invoice.setAmountInWords(NumberToWords.convert(grand));

            List<InvoiceItem> items = new ArrayList<>();
            for (int i = 0; i < tableModel.getRowCount(); i++) {
                InvoiceItem item = new InvoiceItem();
                item.setSlNo(i + 1);
                item.setDescription(tableModel.getValueAt(i, 1) != null ? tableModel.getValueAt(i, 1).toString() : "");
                item.setHsnCode(tableModel.getValueAt(i, 2) != null ? tableModel.getValueAt(i, 2).toString() : "");
                item.setDays((int) parseDouble(tableModel.getValueAt(i, 3), 1));
                item.setQty(parseDouble(tableModel.getValueAt(i, 4), 0));
                item.setRate(parseDouble(tableModel.getValueAt(i, 5), 0));
                item.setAmount(parseDouble(tableModel.getValueAt(i, 6), 0));
                item.setLumpsum((Boolean) tableModel.getValueAt(i, 7));
                items.add(item);
            }
            invoice.setItems(items);

            boolean saved = invoiceDAO.saveInvoice(invoice);
            if (saved) {
                JOptionPane.showMessageDialog(null, "Invoice saved successfully!");
                NavigationManager.goBack(this);
            } else {
                JOptionPane.showMessageDialog(null, "Error saving invoice!");
            }

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }
}